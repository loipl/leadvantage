<?php get_header();

	echo '<div id="content">';

	wats_ticket_access_denied();
	
	echo '</div><br />';

get_footer(); ?>