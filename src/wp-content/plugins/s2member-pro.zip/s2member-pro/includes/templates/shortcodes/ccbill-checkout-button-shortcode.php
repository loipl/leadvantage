<?php
if (realpath (__FILE__) === realpath ($_SERVER["SCRIPT_FILENAME"]))
	exit("Do not access this file directly.");
?>

[s2Member-Pro-ccBill-Button level="%%level%%" ccaps="" desc="%%level_label%% / <?php echo esc_attr (_x ("Description and pricing details here.", "s2member-admin", "s2member")); ?>" cc="USD" custom="%%custom%%" ta="0" tp="0" tt="D" ra="2.95" rp="1" rt="M" rr="1" image="default" output="anchor" /]