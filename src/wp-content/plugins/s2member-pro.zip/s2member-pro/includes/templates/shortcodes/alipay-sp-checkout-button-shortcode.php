<?php
if (realpath (__FILE__) === realpath ($_SERVER["SCRIPT_FILENAME"]))
	exit("Do not access this file directly.");
?>

[s2Member-Pro-AliPay-Button sp="1" ids="0" exp="72" desc="<?php echo esc_attr (_x ("Description and pricing details here.", "s2member-admin", "s2member")); ?>" custom="%%custom%%" ra="0.01" image="default" output="anchor" /]