<?php
if (realpath (__FILE__) === realpath ($_SERVER["SCRIPT_FILENAME"]))
	exit ("Do not access this file directly.");
?>

<a href="%%url%%">
 <img src="%%images%%/ccbill-button.png" style="width:auto; height:auto; border:0;" alt="ccBill" />
</a>