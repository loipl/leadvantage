<?php
if (realpath (__FILE__) === realpath ($_SERVER["SCRIPT_FILENAME"]))
	exit ("Do not access this file directly.");
?>

<a href="%%url%%">
 <img src="%%images%%/alipay-button.gif" style="width:auto; height:auto; border:0;" alt="AliPay" />
</a>