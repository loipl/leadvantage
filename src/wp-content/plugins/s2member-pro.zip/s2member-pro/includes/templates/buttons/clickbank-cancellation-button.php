<?php
if (realpath (__FILE__) === realpath ($_SERVER["SCRIPT_FILENAME"]))
	exit ("Do not access this file directly.");
?>

<a href="http://www.clickbank.com/orderDetail.htm">
 <img src="%%images%%/clickbank-edit-button.png" style="width:auto; height:auto; border:0;" alt="ClickBank" />
</a>